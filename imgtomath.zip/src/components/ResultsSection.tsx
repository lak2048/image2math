import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Copy, Check } from "lucide-react";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";

interface ResultsSectionProps {
  latex: string;
  mathml: string;
  isProcessing: boolean;
}

export const ResultsSection = ({ latex, mathml, isProcessing }: ResultsSectionProps) => {
  const [copiedLatex, setCopiedLatex] = useState(false);
  const [copiedMathml, setCopiedMathml] = useState(false);
  const { toast } = useToast();

  const handleCopyLatex = async () => {
    try {
      await navigator.clipboard.writeText(latex);
      setCopiedLatex(true);
      toast({
        title: "Copied!",
        description: "LaTeX code copied to clipboard",
      });
      setTimeout(() => setCopiedLatex(false), 2000);
    } catch (error) {
      toast({
        title: "Failed to copy",
        description: "Please try again",
        variant: "destructive",
      });
    }
  };

  const handleCopyMathml = async () => {
    try {
      await navigator.clipboard.writeText(mathml);
      setCopiedMathml(true);
      toast({
        title: "Copied!",
        description: "MathML code copied to clipboard",
      });
      setTimeout(() => setCopiedMathml(false), 2000);
    } catch (error) {
      toast({
        title: "Failed to copy",
        description: "Please try again",
        variant: "destructive",
      });
    }
  };

  if (!latex && !isProcessing) return null;

  return (
    <section className="py-20 px-4 bg-background">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold mb-2">Conversion Results</h2>
          <p className="text-muted-foreground">
            Your equation has been converted to LaTeX and MathML formats
          </p>
        </div>

        <div className="space-y-6">
          <Card className="p-8 shadow-[var(--shadow-elegant)]">
            {isProcessing ? (
              <div className="flex flex-col items-center justify-center py-12 gap-4">
                <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
                <p className="text-lg font-medium text-muted-foreground">Processing your equation...</p>
              </div>
            ) : (
              <div className="space-y-8">
                {/* LaTeX Output */}
                <div className="space-y-3">
                  <h3 className="text-xl font-semibold">LaTeX</h3>
                  <div className="relative">
                    <pre className="bg-muted/50 p-6 rounded-lg overflow-x-auto text-sm font-mono border border-border">
                      {latex}
                    </pre>
                    <Button
                      variant="outline"
                      size="icon"
                      className="absolute top-4 right-4"
                      onClick={handleCopyLatex}
                    >
                      {copiedLatex ? (
                        <Check className="w-4 h-4 text-green-600" />
                      ) : (
                        <Copy className="w-4 h-4" />
                      )}
                    </Button>
                  </div>
                </div>

                {/* MathML Output */}
                {mathml && (
                  <div className="space-y-3">
                    <h3 className="text-xl font-semibold">MathML</h3>
                    <div className="relative">
                      <pre className="bg-muted/50 p-6 rounded-lg overflow-x-auto text-sm font-mono border border-border max-h-64">
                        {mathml}
                      </pre>
                      <Button
                        variant="outline"
                        size="icon"
                        className="absolute top-4 right-4"
                        onClick={handleCopyMathml}
                      >
                        {copiedMathml ? (
                          <Check className="w-4 h-4 text-green-600" />
                        ) : (
                          <Copy className="w-4 h-4" />
                        )}
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            )}
          </Card>
        </div>
      </div>
    </section>
  );
};
