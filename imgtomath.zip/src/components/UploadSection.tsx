import { useCallback, useState } from "react";
import { useDropzone } from "react-dropzone";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Upload, Image as ImageIcon, X } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface UploadSectionProps {
  onImageUpload: (file: File) => void;
  onBulkUpload: (files: File[], batchSize: number) => void;
}

export const UploadSection = ({ onImageUpload, onBulkUpload }: UploadSectionProps) => {
  const [preview, setPreview] = useState<string | null>(null);
  const [file, setFile] = useState<File | null>(null);
  const [bulkFiles, setBulkFiles] = useState<File[]>([]);
  const [batchSize, setBatchSize] = useState<number>(50);
  const { toast } = useToast();

  const onDrop = useCallback((acceptedFiles: File[]) => {
    if (acceptedFiles.length === 0) return;

    // Validate all files
    const invalidFiles = acceptedFiles.filter(f => !f.type.startsWith('image/'));
    if (invalidFiles.length > 0) {
      toast({
        title: "Invalid file type",
        description: "Please upload only image files",
        variant: "destructive",
      });
      return;
    }

    const oversizedFiles = acceptedFiles.filter(f => f.size > 10 * 1024 * 1024);
    if (oversizedFiles.length > 0) {
      toast({
        title: "Files too large",
        description: "Some files exceed 10MB limit",
        variant: "destructive",
      });
      return;
    }

    // Single file mode
    if (acceptedFiles.length === 1) {
      const selectedFile = acceptedFiles[0];
      setFile(selectedFile);
      setBulkFiles([]);
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreview(reader.result as string);
      };
      reader.readAsDataURL(selectedFile);
    } else {
      // Bulk mode
      setBulkFiles(acceptedFiles);
      setFile(null);
      setPreview(null);
    }
  }, [toast]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'image/*': ['.png', '.jpg', '.jpeg', '.webp']
    },
    multiple: true,
  });

  const handleProcess = () => {
    if (file) {
      onImageUpload(file);
    }
  };

  const handleBulkProcess = () => {
    if (bulkFiles.length > 0) {
      onBulkUpload(bulkFiles, batchSize);
    }
  };

  const handleClear = () => {
    setPreview(null);
    setFile(null);
    setBulkFiles([]);
  };

  return (
    <section className="py-20 px-4 bg-muted/30" id="upload">
      <div className="max-w-3xl mx-auto">
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold mb-2">Upload Your Equation</h2>
          <p className="text-muted-foreground">
            Drag and drop or click to upload an image of your math equation
          </p>
        </div>

        <Card className="p-8 shadow-[var(--shadow-elegant)]">
          {!preview && bulkFiles.length === 0 ? (
            <div
              {...getRootProps()}
              className={`border-2 border-dashed rounded-lg p-12 text-center cursor-pointer transition-[var(--transition-smooth)] ${
                isDragActive
                  ? 'border-primary bg-primary/5'
                  : 'border-border hover:border-primary/50 hover:bg-muted/50'
              }`}
            >
              <input {...getInputProps()} />
              <div className="flex flex-col items-center gap-4">
                <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center">
                  <Upload className="w-8 h-8 text-primary" />
                </div>
                {isDragActive ? (
                  <p className="text-lg font-medium text-primary">Drop your image here</p>
                ) : (
                  <>
                    <p className="text-lg font-medium">
                      Drag & drop equation images here
                    </p>
                    <p className="text-sm text-muted-foreground">
                      Single or multiple files (PNG, JPG, JPEG, WEBP)
                    </p>
                  </>
                )}
              </div>
            </div>
          ) : preview ? (
            <div className="space-y-6">
              <div className="relative rounded-lg overflow-hidden bg-muted/50 p-4">
                <Button
                  variant="destructive"
                  size="icon"
                  className="absolute top-6 right-6 z-10"
                  onClick={handleClear}
                >
                  <X className="w-4 h-4" />
                </Button>
                <div className="flex items-center justify-center">
                  <img
                    src={preview}
                    alt="Preview"
                    className="max-h-96 object-contain rounded"
                  />
                </div>
              </div>
              <div className="flex gap-4">
                <Button
                  variant="outline"
                  className="flex-1"
                  onClick={handleClear}
                >
                  Choose Different Image
                </Button>
                <Button
                  variant="hero"
                  className="flex-1"
                  onClick={handleProcess}
                >
                  <ImageIcon className="w-4 h-4 mr-2" />
                  Process Equation
                </Button>
              </div>
            </div>
          ) : bulkFiles.length > 0 ? (
            <div className="space-y-6">
              <div className="rounded-lg bg-muted/50 p-4">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h3 className="font-semibold">Bulk Upload</h3>
                    <p className="text-sm text-muted-foreground">
                      {bulkFiles.length} image{bulkFiles.length > 1 ? 's' : ''} selected
                    </p>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={handleClear}
                  >
                    <X className="w-4 h-4" />
                  </Button>
                </div>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-2 max-h-64 overflow-y-auto">
                  {bulkFiles.map((f, idx) => (
                    <div key={idx} className="text-xs p-2 bg-background rounded border truncate">
                      {f.name}
                    </div>
                  ))}
                </div>
              </div>
              
              <div className="flex items-center gap-4 p-4 bg-background rounded-lg border">
                <label className="text-sm font-medium whitespace-nowrap">Batch Size:</label>
                <Select value={batchSize.toString()} onValueChange={(v) => setBatchSize(parseInt(v))}>
                  <SelectTrigger className="w-32">
                    <SelectValue placeholder="Batch size" />
                  </SelectTrigger>
              <SelectContent>
                <SelectItem value="10">10 at a time</SelectItem>
                <SelectItem value="25">25 at a time</SelectItem>
                <SelectItem value="50">50 at a time</SelectItem>
                <SelectItem value="100">100 at a time</SelectItem>
                <SelectItem value="250">250 at a time</SelectItem>
                <SelectItem value="500">500 at a time</SelectItem>
              </SelectContent>
                </Select>
                <p className="text-xs text-muted-foreground">
                  Smaller batches help avoid rate limits
                </p>
              </div>
              
              <div className="flex gap-4">
                <Button
                  variant="outline"
                  className="flex-1"
                  onClick={handleClear}
                >
                  Choose Different Images
                </Button>
                <Button
                  variant="hero"
                  className="flex-1"
                  onClick={handleBulkProcess}
                >
                  <ImageIcon className="w-4 h-4 mr-2" />
                  Process {bulkFiles.length} Image{bulkFiles.length > 1 ? 's' : ''}
                </Button>
              </div>
            </div>
          ) : null}
        </Card>
      </div>
    </section>
  );
};
