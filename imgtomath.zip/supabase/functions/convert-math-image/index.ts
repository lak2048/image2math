import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

async function callAIWithRetry(
  apiKey: string,
  body: object,
  maxRetries = 8
): Promise<Response> {
  let lastError: Error | null = null;
  
  for (let attempt = 0; attempt < maxRetries; attempt++) {
    if (attempt > 0) {
      // Exponential backoff: 2s, 4s, 8s, 16s, 32s...
      const backoffDelay = Math.min(Math.pow(2, attempt) * 2000, 30000);
      console.log(`Retry ${attempt + 1}/${maxRetries}, waiting ${backoffDelay / 1000}s...`);
      await delay(backoffDelay);
    }
    
    try {
      const response = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${apiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(body),
      });
      
      if (response.status === 429) {
        console.log(`Rate limited on attempt ${attempt + 1}`);
        lastError = new Error('Rate limited');
        continue;
      }
      
      if (response.status === 503 || response.status === 502) {
        console.log(`Service unavailable on attempt ${attempt + 1}`);
        lastError = new Error('Service temporarily unavailable');
        continue;
      }
      
      return response;
    } catch (error) {
      console.log(`Network error on attempt ${attempt + 1}:`, error);
      lastError = error instanceof Error ? error : new Error('Network error');
      continue;
    }
  }
  
  throw lastError || new Error('Max retries exceeded');
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { imageBase64 } = await req.json();
    
    if (!imageBase64) {
      return new Response(
        JSON.stringify({ error: 'No image provided' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const LOVABLE_API_KEY = Deno.env.get('LOVABLE_API_KEY');
    if (!LOVABLE_API_KEY) {
      throw new Error('LOVABLE_API_KEY not configured');
    }

    console.log('Processing math image - single AI call for both LaTeX and MathML...');

    // SINGLE AI call to get BOTH LaTeX and MathML - cuts API usage in half!
    let response: Response;
    try {
      response = await callAIWithRetry(LOVABLE_API_KEY, {
        model: 'google/gemini-2.5-flash',
        messages: [
          {
            role: 'system',
            content: `You are a mathematical equation recognition and conversion expert. Your task:
1. Extract the mathematical equation from the image EXACTLY as it appears
2. Convert it to LaTeX format preserving alignment
3. Convert the same equation to valid Presentation MathML 3.0 preserving alignment

CRITICAL - PRESERVE ALIGNMENT:
- Detect if equations are left-aligned, center-aligned, or right-aligned
- For multi-line equations, preserve line breaks and alignment points
- Use LaTeX align/aligned environments for multi-line equations
- In MathML, use <mtable> with appropriate columnalign for multi-line/aligned content

Return your response in this EXACT JSON format (no markdown, no code blocks):
{"latex":"<the LaTeX code>","mathml":"<the complete MathML starting with <math xmlns=...>"}

LaTeX alignment rules:
- For multi-line equations, use \\begin{aligned}...\\end{aligned} or \\begin{align*}...\\end{align*}
- Use & for alignment points and \\\\ for line breaks
- Preserve equation numbering if visible

MathML alignment rules:
- Start with <math xmlns="http://www.w3.org/1998/Math/MathML" display="block">
- Use <mtable columnalign="left"> for left-aligned multi-line equations
- Use <mtable columnalign="center"> for centered equations
- Use <mtable columnalign="right"> for right-aligned equations
- Use <mtr> for rows and <mtd> for cells in tables
- Use <mi> for identifiers, <mn> for numbers, <mo> for operators
- Use <mfrac> for fractions, <msup>/<msub> for super/subscripts
- Use <mrow> for grouping, <mtext> for plain text
- Use <maligngroup/> and <malignmark/> for alignment points
- Preserve ALL text content and spacing from the equation`
          },
          {
            role: 'user',
            content: [
              {
                type: 'text',
                text: 'Extract the math equation from this image. IMPORTANT: Preserve the exact alignment (left/center/right) and layout (single line, multi-line, matrix) as shown in the source image. Return both LaTeX and MathML in the JSON format specified. Return ONLY the JSON object, nothing else.'
              },
              {
                type: 'image_url',
                image_url: { url: imageBase64 }
              }
            ]
          }
        ],
        max_tokens: 4000
      });
    } catch (error) {
      console.error('AI Gateway error after retries:', error);
      return new Response(
        JSON.stringify({ error: 'Rate limit exceeded. Please try again later.' }),
        { status: 429, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (!response.ok) {
      const errorText = await response.text();
      console.error('AI Gateway error:', response.status, errorText);
      
      if (response.status === 429) {
        return new Response(
          JSON.stringify({ error: 'Rate limit exceeded. Please try again later.' }),
          { status: 429, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
      
      if (response.status === 402) {
        return new Response(
          JSON.stringify({ error: 'Payment required. Please add credits to your workspace.' }),
          { status: 402, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      throw new Error(`AI Gateway error: ${response.status}`);
    }

    const data = await response.json();
    let content = data.choices?.[0]?.message?.content?.trim() || '';
    
    console.log('Raw AI response:', content);

    // Parse the JSON response
    let latex = '';
    let mathml = '';
    
    try {
      // Clean up any markdown artifacts
      content = content.replace(/```json\n?/g, '').replace(/```\n?/g, '').trim();
      
      const parsed = JSON.parse(content);
      latex = parsed.latex || '';
      mathml = parsed.mathml || '';
      
      // Clean up MathML
      if (mathml && !mathml.startsWith('<math')) {
        const mathStart = mathml.indexOf('<math');
        if (mathStart > -1) {
          mathml = mathml.substring(mathStart);
        }
      }
      
      console.log('Successfully parsed LaTeX and MathML');
    } catch (parseError) {
      console.error('JSON parse error, falling back to extraction:', parseError);
      
      // Fallback: try to extract LaTeX and MathML from the content
      const latexMatch = content.match(/"latex"\s*:\s*"([^"]+)"/);
      if (latexMatch) latex = latexMatch[1];
      
      const mathmlMatch = content.match(/<math[\s\S]*?<\/math>/);
      if (mathmlMatch) mathml = mathmlMatch[0];
      
      // If still no LaTeX, use the whole content
      if (!latex) latex = content;
    }

    return new Response(
      JSON.stringify({ latex, mathml }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Error in convert-math-image:', error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : 'Unknown error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
