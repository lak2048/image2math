-- Create storage bucket for math conversions
INSERT INTO storage.buckets (id, name, public)
VALUES ('math-conversions', 'math-conversions', true)
ON CONFLICT (id) DO NOTHING;

-- Allow anyone to upload to math-conversions bucket
CREATE POLICY "Allow public uploads to math-conversions"
ON storage.objects FOR INSERT
WITH CHECK (bucket_id = 'math-conversions');

-- Allow anyone to read from math-conversions bucket  
CREATE POLICY "Allow public reads from math-conversions"
ON storage.objects FOR SELECT
USING (bucket_id = 'math-conversions');

-- Allow anyone to delete from math-conversions bucket
CREATE POLICY "Allow public deletes from math-conversions"
ON storage.objects FOR DELETE
USING (bucket_id = 'math-conversions');