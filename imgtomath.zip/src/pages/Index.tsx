import { useState, useRef } from "react";
import { Hero } from "@/components/Hero";
import { UploadSection } from "@/components/UploadSection";
import { ResultsSection } from "@/components/ResultsSection";
import { BulkResultItem } from "@/components/BulkResultItem";
import { ProcessingProgress } from "@/components/ProcessingProgress";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Download } from "lucide-react";
import JSZip from "jszip";

interface BulkResult {
  filename: string;
  latex: string;
  mathml: string;
  xmlUrl: string;
  imageUrl: string;
  status: 'success' | 'error';
  error?: string;
}

const Index = () => {
  const [latex, setLatex] = useState("");
  const [mathml, setMathml] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);
  const [bulkResults, setBulkResults] = useState<BulkResult[]>([]);
  const [processingCount, setProcessingCount] = useState(0);
  const [totalCount, setTotalCount] = useState(0);
  const [startTime, setStartTime] = useState(0);
  const uploadRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  const handleGetStarted = () => {
    uploadRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  const handleImageUpload = async (file: File) => {
    setIsProcessing(true);
    setBulkResults([]);
    
    try {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      
      const imageBase64 = await new Promise<string>((resolve, reject) => {
        reader.onload = () => resolve(reader.result as string);
        reader.onerror = reject;
      });

      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/convert-math-image`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ imageBase64 }),
        }
      );

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to process image');
      }

      const data = await response.json();
      setLatex(data.latex);
      setMathml(data.mathml);
      
      toast({
        title: "Processing complete!",
        description: "Your equation has been converted to LaTeX and MathML",
      });
    } catch (error) {
      console.error('Error processing image:', error);
      toast({
        title: "Processing failed",
        description: error instanceof Error ? error.message : "Failed to convert image",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  };

  // Helper function to delay execution
  const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

  // Helper function to process image with retry logic (now 2x faster with single AI call)
  const processImageWithRetry = async (imageBase64: string, maxRetries = 6): Promise<{ latex: string; mathml: string }> => {
    let lastError: Error | null = null;
    
    for (let attempt = 0; attempt < maxRetries; attempt++) {
      try {
        // Add delay before retry (exponential backoff, capped at 30s)
        if (attempt > 0) {
          const backoffDelay = Math.min(Math.pow(2, attempt) * 2000, 30000); // 2s, 4s, 8s, 16s, 30s...
          console.log(`Retry attempt ${attempt + 1}/${maxRetries}, waiting ${backoffDelay / 1000}s...`);
          await delay(backoffDelay);
        }

        const response = await fetch(
          `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/convert-math-image`,
          {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({ imageBase64 }),
          }
        );

        if (response.status === 429) {
          // Rate limited - wait longer and retry
          const retryAfter = parseInt(response.headers.get('Retry-After') || '60', 10);
          console.log(`Rate limited, waiting ${retryAfter}s before retry...`);
          await delay(retryAfter * 1000);
          throw new Error('Rate limited, retrying...');
        }

        if (response.status === 402) {
          throw new Error('Payment required - please add credits to your workspace');
        }

        if (!response.ok) {
          const errorData = await response.json().catch(() => ({}));
          throw new Error(errorData.error || 'Failed to process image');
        }

        return await response.json();
      } catch (error) {
        lastError = error instanceof Error ? error : new Error('Unknown error');
        console.log(`Attempt ${attempt + 1}/${maxRetries} failed:`, lastError.message);
        
        // If it's a payment error, don't retry
        if (lastError.message.includes('Payment required')) {
          throw lastError;
        }
      }
    }

    throw lastError || new Error('Failed after retries');
  };

  const handleBulkUpload = async (files: File[], batchSize: number = 50) => {
    setIsProcessing(true);
    setLatex("");
    setMathml("");
    setBulkResults([]);
    setTotalCount(files.length);
    setProcessingCount(0);
    setStartTime(Date.now());

    const results: BulkResult[] = [];
    const totalBatches = Math.ceil(files.length / batchSize);

    for (let batchIndex = 0; batchIndex < totalBatches; batchIndex++) {
      const startIdx = batchIndex * batchSize;
      const endIdx = Math.min(startIdx + batchSize, files.length);
      const batchFiles = files.slice(startIdx, endIdx);

      // Process each file in the current batch
      for (let i = 0; i < batchFiles.length; i++) {
        const file = batchFiles[i];
        const globalIndex = startIdx + i;
        setProcessingCount(globalIndex + 1);
        
        try {
          // Convert to base64
          const reader = new FileReader();
          reader.readAsDataURL(file);
          
          const imageBase64 = await new Promise<string>((resolve, reject) => {
            reader.onload = () => resolve(reader.result as string);
            reader.onerror = reject;
          });

          // Call edge function with retry logic
          const data = await processImageWithRetry(imageBase64);
          
          // Save MathML as .xml file to storage with unique timestamp
          const baseFilename = file.name.replace(/\.[^/.]+$/, '');
          const timestamp = Date.now() + globalIndex; // Add index to ensure uniqueness
          const xmlFilename = `${baseFilename}_${timestamp}.xml`;
          const xmlBlob = new Blob([data.mathml], { type: 'application/xml' });
          
          const { error: uploadError } = await supabase.storage
            .from('math-conversions')
            .upload(xmlFilename, xmlBlob, {
              upsert: true,
              contentType: 'application/xml'
            });

          if (uploadError) throw uploadError;

          const { data: { publicUrl } } = supabase.storage
            .from('math-conversions')
            .getPublicUrl(xmlFilename);

          results.push({
            filename: file.name,
            latex: data.latex,
            mathml: data.mathml,
            xmlUrl: publicUrl,
            imageUrl: imageBase64,
            status: 'success'
          });
        } catch (error) {
          results.push({
            filename: file.name,
            latex: '',
            mathml: '',
            xmlUrl: '',
            imageUrl: '',
            status: 'error',
            error: error instanceof Error ? error.message : 'Failed to process'
          });
        }
        
        setBulkResults([...results]);
        
        // Add delay between images (6 seconds - faster now with single AI call per image)
        if (i < batchFiles.length - 1) {
          await delay(6000);
        }
      }

      // Pause between batches (20 seconds) to avoid rate limiting
      if (batchIndex < totalBatches - 1) {
        toast({
          title: `Batch ${batchIndex + 1}/${totalBatches} complete`,
          description: `Waiting 20 seconds before next batch...`,
        });
        await delay(20000);
      }
    }

    setIsProcessing(false);
    toast({
      title: "Bulk processing complete!",
      description: `Processed ${results.filter(r => r.status === 'success').length} of ${files.length} images`,
    });
  };

  const handleBatchDownload = async () => {
    const successfulResults = bulkResults.filter(r => r.status === 'success');
    
    if (successfulResults.length === 0) {
      toast({
        title: "No files to download",
        description: "There are no successfully processed files to download",
        variant: "destructive",
      });
      return;
    }

    try {
      const zip = new JSZip();
      
      // Add both LaTeX (.tex) and MathML (.xml) files for each result
      for (const result of successfulResults) {
        const baseFilename = result.filename.replace(/\.[^/.]+$/, '');
        
        // Add LaTeX file
        zip.file(`${baseFilename}.tex`, result.latex);
        
        // Add MathML file
        zip.file(`${baseFilename}.xml`, result.mathml);
      }
      
      // Generate zip file
      const zipBlob = await zip.generateAsync({ type: 'blob' });
      
      // Download zip file
      const url = URL.createObjectURL(zipBlob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `math-conversions-${new Date().toISOString().split('T')[0]}.zip`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      
      toast({
        title: "Download complete!",
        description: `Downloaded ${successfulResults.length * 2} files (${successfulResults.length} LaTeX + ${successfulResults.length} MathML) as ZIP`,
      });
    } catch (error) {
      toast({
        title: "Download failed",
        description: error instanceof Error ? error.message : "Failed to create ZIP file",
        variant: "destructive",
      });
    }
  };

  return (
    <main className="min-h-screen">
      <Hero onGetStarted={handleGetStarted} />
      <div ref={uploadRef}>
        <UploadSection 
          onImageUpload={handleImageUpload} 
          onBulkUpload={handleBulkUpload}
        />
      </div>
      
      {bulkResults.length > 0 ? (
        <section className="py-20 px-4">
          <div className="max-w-6xl mx-auto">
            <div className="flex items-center justify-between mb-8">
              <h2 className="text-3xl font-bold">Bulk Processing Results</h2>
              {!isProcessing && bulkResults.some(r => r.status === 'success') && (
                <Button onClick={handleBatchDownload} variant="hero">
                  <Download className="w-4 h-4 mr-2" />
                  Download All as ZIP
                </Button>
              )}
            </div>
            {isProcessing && (
              <ProcessingProgress 
                current={processingCount} 
                total={totalCount} 
                startTime={startTime} 
              />
            )}
            <div className="grid gap-4">
              {bulkResults.map((result, idx) => (
                <BulkResultItem
                  key={idx}
                  filename={result.filename}
                  latex={result.latex}
                  mathml={result.mathml}
                  xmlUrl={result.xmlUrl}
                  imageUrl={result.imageUrl}
                  status={result.status}
                  error={result.error}
                />
              ))}
            </div>
          </div>
        </section>
      ) : (
        <ResultsSection latex={latex} mathml={mathml} isProcessing={isProcessing} />
      )}
    </main>
  );
};

export default Index;
