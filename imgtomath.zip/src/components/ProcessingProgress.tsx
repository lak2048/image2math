import { Progress } from "@/components/ui/progress";
import { Clock, Loader2 } from "lucide-react";

interface ProcessingProgressProps {
  current: number;
  total: number;
  startTime: number;
}

export const ProcessingProgress = ({ current, total, startTime }: ProcessingProgressProps) => {
  const percentage = total > 0 ? Math.round((current / total) * 100) : 0;
  
  // Calculate ETA
  const elapsed = Date.now() - startTime;
  const avgTimePerImage = current > 0 ? elapsed / current : 0;
  const remaining = (total - current) * avgTimePerImage;
  
  const formatTime = (ms: number) => {
    if (ms <= 0) return "Calculating...";
    const seconds = Math.floor(ms / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    
    if (hours > 0) {
      return `${hours}h ${minutes % 60}m ${seconds % 60}s`;
    } else if (minutes > 0) {
      return `${minutes}m ${seconds % 60}s`;
    }
    return `${seconds}s`;
  };

  return (
    <div className="w-full max-w-2xl mx-auto mb-8 p-6 rounded-xl bg-card border border-border">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <Loader2 className="w-5 h-5 animate-spin text-primary" />
          <span className="font-semibold text-foreground">Processing Images</span>
        </div>
        <span className="text-2xl font-bold text-primary">{percentage}%</span>
      </div>
      
      <Progress value={percentage} className="h-3 mb-4" />
      
      <div className="flex items-center justify-between text-sm text-muted-foreground">
        <span>{current} of {total} images</span>
        <div className="flex items-center gap-1.5">
          <Clock className="w-4 h-4" />
          <span>ETA: {formatTime(remaining)}</span>
        </div>
      </div>
    </div>
  );
};
