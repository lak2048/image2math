import { Button } from "@/components/ui/button";
import { Upload } from "lucide-react";

interface HeroProps {
  onGetStarted: () => void;
}

export const Hero = ({ onGetStarted }: HeroProps) => {
  return (
    <section className="min-h-[90vh] flex items-center justify-center px-4 py-20 bg-gradient-to-b from-background via-background to-muted/30">
      <div className="max-w-5xl mx-auto text-center space-y-8 animate-in fade-in duration-1000">
        <div className="space-y-4">
          <h1 className="text-5xl md:text-7xl font-bold tracking-tight">
            <span className="bg-gradient-to-r from-primary to-primary-glow bg-clip-text text-transparent">
              Math Equation
            </span>
            <br />
            Recognition Tool
          </h1>
          <p className="text-xl md:text-2xl text-muted-foreground max-w-2xl mx-auto">
            Transform handwritten or printed math equations into clean LaTeX instantly
          </p>
        </div>

        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center pt-8">
          <Button 
            variant="hero" 
            size="lg" 
            onClick={onGetStarted}
            className="gap-2"
          >
            <Upload className="w-5 h-5" />
            Get Started
          </Button>
          <Button 
            variant="outline" 
            size="lg"
          >
            View Examples
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 pt-16 max-w-4xl mx-auto">
          <FeatureCard
            title="Fast Recognition"
            description="Upload your equation and get LaTeX output in seconds"
          />
          <FeatureCard
            title="High Accuracy"
            description="Advanced OCR technology for precise equation recognition"
          />
          <FeatureCard
            title="Easy Export"
            description="Copy LaTeX code with one click for use anywhere"
          />
        </div>
      </div>
    </section>
  );
};

const FeatureCard = ({ title, description }: { title: string; description: string }) => {
  return (
    <div className="p-6 rounded-lg bg-card border border-border shadow-[var(--shadow-soft)] hover:shadow-[var(--shadow-elegant)] transition-[var(--transition-smooth)] hover:-translate-y-1">
      <h3 className="text-lg font-semibold mb-2 text-foreground">{title}</h3>
      <p className="text-sm text-muted-foreground">{description}</p>
    </div>
  );
};
