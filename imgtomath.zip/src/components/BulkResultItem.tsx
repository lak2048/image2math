import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Check, Copy, ChevronDown, ChevronUp, Download } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";

interface BulkResultItemProps {
  filename: string;
  latex: string;
  mathml: string;
  xmlUrl: string;
  imageUrl: string;
  status: 'success' | 'error';
  error?: string;
}

export const BulkResultItem = ({ filename, latex, mathml, xmlUrl, imageUrl, status, error }: BulkResultItemProps) => {
  const [isOpen, setIsOpen] = useState(false);
  const [copiedLatex, setCopiedLatex] = useState(false);
  const [copiedMathml, setCopiedMathml] = useState(false);
  const { toast } = useToast();

  const handleCopyLatex = async () => {
    await navigator.clipboard.writeText(latex);
    setCopiedLatex(true);
    setTimeout(() => setCopiedLatex(false), 2000);
    toast({
      title: "Copied!",
      description: "LaTeX copied to clipboard",
    });
  };

  const handleCopyMathml = async () => {
    await navigator.clipboard.writeText(mathml);
    setCopiedMathml(true);
    setTimeout(() => setCopiedMathml(false), 2000);
    toast({
      title: "Copied!",
      description: "MathML copied to clipboard",
    });
  };

  if (status === 'error') {
    return (
      <Card className="p-4">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <h3 className="font-semibold">{filename}</h3>
            <p className="text-sm text-destructive mt-2">{error}</p>
          </div>
          <span className="text-xs px-2 py-1 rounded bg-red-100 text-red-800">
            error
          </span>
        </div>
      </Card>
    );
  }

  return (
    <Collapsible open={isOpen} onOpenChange={setIsOpen}>
      <Card className="p-4">
        <div className="flex items-start justify-between mb-2">
          <div className="flex-1">
            <h3 className="font-semibold">{filename}</h3>
          </div>
          <span className="text-xs px-2 py-1 rounded bg-green-100 text-green-800">
            success
          </span>
        </div>

        <div className="flex items-center gap-2 mt-3">
          <CollapsibleTrigger asChild>
            <Button variant="outline" size="sm">
              {isOpen ? (
                <>
                  <ChevronUp className="w-4 h-4 mr-2" />
                  Hide Preview
                </>
              ) : (
                <>
                  <ChevronDown className="w-4 h-4 mr-2" />
                  Show Preview
                </>
              )}
            </Button>
          </CollapsibleTrigger>
          <a 
            href={xmlUrl}
            download={`${filename.replace(/\.[^/.]+$/, '')}.xml`}
            className="inline-flex items-center text-sm text-primary hover:underline"
          >
            <Download className="w-4 h-4 mr-1" />
            Download XML
          </a>
        </div>

        <CollapsibleContent className="mt-4">
          <div className="space-y-4">
            {/* Image Comparison Section */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Source Image */}
              <div>
                <h4 className="font-semibold text-sm mb-2">Source Image</h4>
                <div className="bg-muted p-3 rounded-md flex items-center justify-center min-h-32">
                  <img 
                    src={imageUrl} 
                    alt={`Source: ${filename}`}
                    className="max-w-full max-h-48 object-contain rounded"
                  />
                </div>
              </div>

              {/* MathML Rendered Preview */}
              <div>
                <h4 className="font-semibold text-sm mb-2">MathML Preview</h4>
                <div 
                  className="bg-muted p-3 rounded-md flex items-center justify-center min-h-32 overflow-auto"
                  dangerouslySetInnerHTML={{ __html: mathml }}
                />
              </div>
            </div>

            {/* Code Output Section */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* LaTeX Output */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <h4 className="font-semibold text-sm">LaTeX Code</h4>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleCopyLatex}
                    className="h-8"
                  >
                    {copiedLatex ? (
                      <Check className="w-4 h-4" />
                    ) : (
                      <Copy className="w-4 h-4" />
                    )}
                  </Button>
                </div>
                <div className="bg-muted p-3 rounded-md max-h-32 overflow-y-auto">
                  <code className="text-sm break-all">{latex}</code>
                </div>
              </div>

              {/* MathML Output */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <h4 className="font-semibold text-sm">MathML Code</h4>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleCopyMathml}
                    className="h-8"
                  >
                    {copiedMathml ? (
                      <Check className="w-4 h-4" />
                    ) : (
                      <Copy className="w-4 h-4" />
                    )}
                  </Button>
                </div>
                <div className="bg-muted p-3 rounded-md max-h-32 overflow-y-auto">
                  <code className="text-sm break-all">{mathml}</code>
                </div>
              </div>
            </div>
          </div>
        </CollapsibleContent>
      </Card>
    </Collapsible>
  );
};
